package ir.persian.voiceoptimizer.rules.typography

import ir.persian.voiceoptimizer.rules.TypographyRule
import javax.inject.Inject

/**
 * Replaces Arabic Kaf (ك U+0643) with Persian Kaf (ک U+06A9)
 * and Arabic Yeh (ي U+064A) with Persian Yeh (ی U+06CC).
 * This is the single most impactful rule for correct TTS pronunciation.
 */
class ArabicToFarsiCharRule @Inject constructor() : TypographyRule {
    override fun process(text: String): String =
        text
            .replace('\u0643', '\u06A9') // ك → ک
            .replace('\u064A', '\u06CC') // ي → ی
            .replace('\u0649', '\u06CC') // ى → ی  (Alef Maqsura)
}

/**
 * Normalizes whitespace:
 * - Collapses multiple spaces/tabs into a single space.
 * - Replaces ZWNJ (U+200C) sequences with a single ZWNJ.
 * - Removes zero-width space (U+200B).
 */
class WhitespaceNormalizationRule @Inject constructor() : TypographyRule {
    override fun process(text: String): String =
        text
            .replace('\u200B', '\u0000').replace("\u0000", "") // remove ZWSP
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\u200C{2,}"), "\u200C")
}

/**
 * Fixes punctuation spacing for Persian:
 * - Removes space before sentence-ending punctuation: ، ؟ ! . ؛ :
 * - Ensures exactly one space after those marks (unless end of string).
 */
class PunctuationSpacingRule @Inject constructor() : TypographyRule {
    // Space before Persian/Arabic punctuation
    private val spaceBefore = Regex("\\s+([،؟!.؛:])")
    // No space after punctuation (but not at end of string)
    private val noSpaceAfter = Regex("([،؟!.؛:])(?!\\s|$)")

    override fun process(text: String): String =
        text
            .replace(spaceBefore, "$1")
            .replace(noSpaceAfter, "$1 ")
}

/**
 * Normalizes Persian numerals (٠-٩) to ASCII (0-9) so TTS engines
 * read them as digits rather than guessing.
 */
class PersianDigitNormalizationRule @Inject constructor() : TypographyRule {
    private val persianDigits = mapOf(
        '٠' to '0', '١' to '1', '٢' to '2', '٣' to '3', '٤' to '4',
        '٥' to '5', '٦' to '6', '٧' to '7', '٨' to '8', '٩' to '9',
        '۰' to '0', '۱' to '1', '۲' to '2', '۳' to '3', '۴' to '4',
        '۵' to '5', '۶' to '6', '۷' to '7', '۸' to '8', '۹' to '9',
    )

    override fun process(text: String): String =
        text.map { persianDigits[it] ?: it }.joinToString("")
}

/**
 * Replaces Western quotation marks (" ") and guillemets (« ») with
 * Persian-appropriate alternatives for consistent TTS treatment.
 */
class QuotationNormalizationRule @Inject constructor() : TypographyRule {
    override fun process(text: String): String =
        text
            .replace('"', '\"')
            .replace('\u201C', '\"') // "
            .replace('\u201D', '\"') // "
            .replace('«', '\"')
            .replace('»', '\"')
}
