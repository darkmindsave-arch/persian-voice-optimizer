package ir.persian.voiceoptimizer.rules.diacritics

import ir.persian.voiceoptimizer.rules.DiacriticsRule
import javax.inject.Inject

/**
 * Applies rule-based diacritization to the most ambiguous common Persian words.
 *
 * This is NOT a full statistical diacritizer — it targets high-frequency words
 * where the undiacritized form causes TTS mispronunciation. A full model-based
 * diacritizer (e.g. Mishkal-Python or Farsi-Diac) can replace this as an
 * optional dependency in a future release.
 *
 * Rules are ordered from most-specific to least-specific to avoid partial matches.
 */
class SmartDiacriticsRule @Inject constructor() : DiacriticsRule {
    /**
     * Map of exact word → diacritized form (including ZWNJ where applicable).
     * Entries use word-boundary matching to avoid mid-word substitution.
     */
    private val wordDiacritics: Map<Regex, String> = buildMap {
        // Verb "است" (is) — most common source of mispronunciation
        put(Regex("\\bاست\\b"), "اَست")
        // "را" (direct object marker)
        put(Regex("\\bرا\\b"), "رَا")
        // "که" (that/which) — schwa vowel
        put(Regex("\\bکه\\b"), "کِه")
        // "با" (with)
        put(Regex("\\bبا\\b"), "بَا")
        // "در" (in/door) — context-insensitive; "in" form vastly more common
        put(Regex("\\bدر\\b"), "دَر")
        // "از" (from)
        put(Regex("\\bاز\\b"), "اَز")
        // "به" (to)
        put(Regex("\\bبه\\b"), "بِه")
        // "هم" (also/together)
        put(Regex("\\bهم\\b"), "هَم")
        // "می" (continuous prefix — already handled by VerbPrefixZwnjRule, diacritize stem)
        put(Regex("\\bنیست\\b"), "نِیست")
        put(Regex("\\bشد\\b"), "شُد")
        put(Regex("\\bشده\\b"), "شُدِه")
        put(Regex("\\bمی‌شود\\b"), "می‌شَوَد")
        put(Regex("\\bمی‌کند\\b"), "می‌کُنَد")
    }

    override fun process(text: String): String {
        var result = text
        wordDiacritics.forEach { (pattern, replacement) ->
            result = result.replace(pattern, replacement)
        }
        return result
    }
}
