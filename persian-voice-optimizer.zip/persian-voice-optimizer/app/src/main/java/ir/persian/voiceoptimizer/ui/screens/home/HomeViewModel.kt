package ir.persian.voiceoptimizer.ui.screens.home

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.persian.voiceoptimizer.core.domain.model.EpubFile
import ir.persian.voiceoptimizer.core.domain.model.OptimizationMode
import ir.persian.voiceoptimizer.core.domain.model.ProcessingOptions
import ir.persian.voiceoptimizer.core.domain.model.ProcessingResult
import ir.persian.voiceoptimizer.core.domain.usecase.ProcessEpubUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val selectedFile: EpubFile? = null,
    val options: ProcessingOptions = ProcessingOptions(),
    val isProcessing: Boolean = false,
    val progress: Int = 0,
    val progressMessage: String = "",
    val outputUri: Uri? = null,
    val chaptersProcessed: Int = 0,
    val error: String? = null,
    /** Raw text sample from first chapter before processing — shown in PreviewScreen. */
    val previewOriginal: String = "",
    /** Same sample after processing. */
    val previewProcessed: String = "",
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val processEpubUseCase: ProcessEpubUseCase,
) : ViewModel() {

    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()

    fun onFileSelected(uri: Uri, name: String, sizeBytes: Long) {
        _state.update {
            it.copy(
                selectedFile = EpubFile(uri, name, sizeBytes),
                outputUri = null,
                error = null,
                progress = 0,
                progressMessage = "",
                previewOriginal = "",
                previewProcessed = "",
            )
        }
    }

    fun onModeChanged(mode: OptimizationMode) {
        _state.update { it.copy(options = it.options.copy(mode = mode)) }
    }

    fun onSmartDiacriticsToggled(enabled: Boolean) {
        _state.update { it.copy(options = it.options.copy(enableSmartDiacritics = enabled)) }
    }

    fun onProcessClicked() {
        val file = _state.value.selectedFile ?: return
        viewModelScope.launch {
            _state.update { it.copy(isProcessing = true, outputUri = null, error = null) }
            processEpubUseCase(file, _state.value.options).collect { result ->
                when (result) {
                    is ProcessingResult.Progress -> _state.update {
                        it.copy(progress = result.percent, progressMessage = result.message)
                    }
                    is ProcessingResult.Success -> _state.update {
                        it.copy(
                            isProcessing = false,
                            outputUri = result.outputUri,
                            chaptersProcessed = result.chaptersProcessed,
                            previewOriginal = result.previewOriginal,
                            previewProcessed = result.previewProcessed,
                        )
                    }
                    is ProcessingResult.Failure -> _state.update {
                        it.copy(
                            isProcessing = false,
                            error = result.cause.message ?: "خطای ناشناخته",
                        )
                    }
                }
            }
        }
    }

    fun clearError() = _state.update { it.copy(error = null) }
}
