package ir.persian.voiceoptimizer.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PrimaryColor = Color(0xFF5B8DEF)       // Calm blue
private val SecondaryColor = Color(0xFF7EC8A4)     // Soft teal
private val TertiaryColor = Color(0xFFE8A87C)      // Warm amber
private val BackgroundDark = Color(0xFF111318)
private val SurfaceDark = Color(0xFF1C2028)
private val BackgroundLight = Color(0xFFF5F7FA)
private val SurfaceLight = Color(0xFFFFFFFF)

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryColor,
    secondary = SecondaryColor,
    tertiary = TertiaryColor,
    background = BackgroundDark,
    surface = SurfaceDark,
    onPrimary = Color.White,
    onBackground = Color(0xFFE2E6EE),
    onSurface = Color(0xFFCDD3DE),
)

private val LightColorScheme = lightColorScheme(
    primary = PrimaryColor,
    secondary = SecondaryColor,
    tertiary = TertiaryColor,
    background = BackgroundLight,
    surface = SurfaceLight,
    onPrimary = Color.White,
    onBackground = Color(0xFF1A1E27),
    onSurface = Color(0xFF2D3444),
)

@Composable
fun PersianVoiceOptimizerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = PersianTypography,
        content = content,
    )
}
