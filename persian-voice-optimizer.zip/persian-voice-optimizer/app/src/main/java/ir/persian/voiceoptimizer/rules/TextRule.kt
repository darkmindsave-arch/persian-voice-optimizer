package ir.persian.voiceoptimizer.rules

/**
 * A single, independently testable text transformation rule.
 * Each rule operates on a plain-text string and returns the transformed result.
 * Rules must be stateless and idempotent.
 */
fun interface TextRule {
    fun process(text: String): String
}

/** Marker for rules that fix Persian/Unicode typography. */
interface TypographyRule : TextRule

/** Marker for rules that normalize Persian grammar for better TTS parsing. */
interface GrammarRule : TextRule

/** Marker for rules that improve raw TTS output quality. */
interface TtsRule : TextRule

/** Marker for rules that add natural human reading pacing cues. */
interface HumanizeRule : TextRule

/** Marker for rules that add Persian diacritics (اعراب). */
interface DiacriticsRule : TextRule
