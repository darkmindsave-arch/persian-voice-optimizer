package ir.persian.voiceoptimizer.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import ir.persian.voiceoptimizer.ui.screens.home.HomeScreen
import ir.persian.voiceoptimizer.ui.screens.preview.PreviewScreen
import ir.persian.voiceoptimizer.ui.screens.settings.SettingsScreen

object Routes {
    const val HOME = "home"
    const val SETTINGS = "settings"
    const val PREVIEW = "preview"
}

@Composable
fun AppNavGraph() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Routes.HOME) {

        composable(Routes.HOME) {
            HomeScreen(
                onNavigateToSettings = { navController.navigate(Routes.SETTINGS) },
                onNavigateToPreview = { original, processed ->
                    // Encode strings as nav args via saved state handle
                    navController.currentBackStackEntry?.savedStateHandle?.apply {
                        set("original", original)
                        set("processed", processed)
                    }
                    navController.navigate(Routes.PREVIEW)
                }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }

        composable(Routes.PREVIEW) {
            val previousEntry = navController.previousBackStackEntry
            val original = previousEntry?.savedStateHandle?.get<String>("original") ?: ""
            val processed = previousEntry?.savedStateHandle?.get<String>("processed") ?: ""
            PreviewScreen(
                originalSample = original,
                processedSample = processed,
                onBack = { navController.popBackStack() },
            )
        }
    }
}
