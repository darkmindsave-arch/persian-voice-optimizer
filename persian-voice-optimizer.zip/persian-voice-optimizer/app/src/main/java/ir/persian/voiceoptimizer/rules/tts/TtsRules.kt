package ir.persian.voiceoptimizer.rules.tts

import ir.persian.voiceoptimizer.rules.TtsRule
import javax.inject.Inject

/**
 * Ensures every sentence ending in "." has exactly one space after it,
 * and adds a period to paragraph-ending lines that lack terminal punctuation.
 * This prevents TTS from running consecutive sentences together.
 */
class SentenceBoundaryRule @Inject constructor() : TtsRule {
    private val missingTerminal = Regex("([^\\.!?؟،؛\\n])\\n")
    private val doublePeriod = Regex("\\.{2,}")

    override fun process(text: String): String =
        text
            .replace(missingTerminal, "$1.\n")
            .replace(doublePeriod, "…")
}

/**
 * Replaces inline URL/email patterns with a spoken-language description
 * so TTS doesn't spell out "h-t-t-p-s-colon-slash…".
 */
class UrlReplacementRule @Inject constructor() : TtsRule {
    private val urlPattern = Regex("https?://\\S+")
    private val emailPattern = Regex("[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}")

    override fun process(text: String): String =
        text
            .replace(urlPattern, "(لینک)")
            .replace(emailPattern, "(ایمیل)")
}

/**
 * Spells out common English abbreviations found in Persian text.
 * Limited set — extensible via a map injection.
 */
class EnglishAbbreviationRule @Inject constructor() : TtsRule {
    private val abbreviations = mapOf(
        Regex("\\bAI\\b") to "هوش مصنوعی",
        Regex("\\bIT\\b") to "فناوری اطلاعات",
        Regex("\\bAPI\\b") to "رابط برنامه‌نویسی",
        Regex("\\bPDF\\b") to "پی‌دی‌اف",
        Regex("\\bUI\\b") to "رابط کاربری",
        Regex("\\bUX\\b") to "تجربه کاربری",
    )

    override fun process(text: String): String {
        var result = text
        abbreviations.forEach { (pattern, replacement) ->
            result = result.replace(pattern, replacement)
        }
        return result
    }
}

/**
 * Removes HTML entities that survive XHTML parsing and would be read
 * literally by TTS ("ampersand nbsp semicolon" etc.).
 */
class HtmlEntityCleanupRule @Inject constructor() : TtsRule {
    private val entity = Regex("&[a-zA-Z]{2,8};|&#[0-9]{1,6};|&#x[0-9a-fA-F]{1,6};")
    private val namedEntities = mapOf(
        "&nbsp;" to " ",
        "&amp;" to "و",
        "&lt;" to "",
        "&gt;" to "",
        "&quot;" to "\"",
        "&apos;" to "'",
    )

    override fun process(text: String): String {
        var result = text
        namedEntities.forEach { (entity, replacement) ->
            result = result.replace(entity, replacement)
        }
        // Remove any remaining unknown entities
        return result.replace(entity, "")
    }
}
