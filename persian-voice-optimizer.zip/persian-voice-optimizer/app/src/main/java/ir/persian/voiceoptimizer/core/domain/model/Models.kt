package ir.persian.voiceoptimizer.core.domain.model

import android.net.Uri

/**
 * Represents an imported EPUB file ready for processing.
 */
data class EpubFile(
    val uri: Uri,
    val name: String,
    val sizeBytes: Long,
)

/**
 * Optimization mode controlling which rule categories are active.
 */
enum class OptimizationMode {
    /** Typography + basic character normalization only. */
    NORMAL,

    /** All rules except HumanVoice. Natural reading flow. */
    NATURAL,

    /** All rules including HumanVoice pacing and breath marks. */
    HUMAN_VOICE,
}

/**
 * User-configurable processing options.
 */
data class ProcessingOptions(
    val mode: OptimizationMode = OptimizationMode.NATURAL,
    val enableSmartDiacritics: Boolean = false,
)

/**
 * Result emitted during processing. Sealed hierarchy — exhaustive pattern matching enforced.
 */
sealed interface ProcessingResult {
    data class Progress(val percent: Int, val message: String) : ProcessingResult
    data class Success(
        val outputUri: Uri,
        val chaptersProcessed: Int,
        /** Plain-text excerpt from first chapter before processing. For PreviewScreen. */
        val previewOriginal: String,
        /** Same excerpt after processing. */
        val previewProcessed: String,
    ) : ProcessingResult
    data class Failure(val cause: Throwable) : ProcessingResult
}

/**
 * Lightweight representation of a single EPUB chapter (XHTML spine item).
 */
data class EpubChapter(
    val id: String,
    val href: String,
    val originalHtml: String,
)
