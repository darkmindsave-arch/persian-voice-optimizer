package ir.persian.voiceoptimizer

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PersianVoiceOptimizerApp : Application()
