package ir.persian.voiceoptimizer.rules.grammar

import ir.persian.voiceoptimizer.rules.GrammarRule
import javax.inject.Inject

/**
 * Expands common Persian abbreviations so TTS reads the full form.
 * e.g. "ص." → "صفحه‌ی" , "ج." → "جلد"
 */
class AbbreviationExpansionRule @Inject constructor() : GrammarRule {
    private val expansions = mapOf(
        Regex("\\bص\\.") to "صفحه‌ی",
        Regex("\\bج\\.") to "جلد",
        Regex("\\bش\\.") to "شماره",
        Regex("\\bتل\\.") to "تلفن",
        Regex("\\bدکتر\\.") to "دکتر",
        Regex("\\bمهندس\\.") to "مهندس",
        Regex("\\bع\\.") to "علیه‌السلام",
        Regex("\\bص\\.ع\\.") to "صلی‌الله علیه و آله",
    )

    override fun process(text: String): String {
        var result = text
        expansions.forEach { (pattern, replacement) ->
            result = result.replace(pattern, replacement)
        }
        return result
    }
}

/**
 * Removes stray diacritics (تشدید, فتحه, etc.) from non-diacritized text
 * to prevent TTS mispronunciation. Only applies when smart diacritics mode is OFF.
 * When enabled, existing diacritics are stripped so the smart diacritics pass can re-add them.
 */
class StripRawDiacriticsRule @Inject constructor() : GrammarRule {
    // Unicode range for Arabic diacritics: U+064B–U+065F + Tatweel
    private val diacriticRange = Regex("[\u064B-\u065F\u0640]")

    override fun process(text: String): String = text.replace(diacriticRange, "")
}

/**
 * Inserts ZWNJ (U+200C) between certain compound verb prefixes and their stems
 * to prevent incorrect word-joining artifacts in some TTS engines.
 *
 * Targeted prefix: می (continuous marker), نمی (negation).
 */
class VerbPrefixZwnjRule @Inject constructor() : GrammarRule {
    // "می" or "نمی" followed by a Persian letter WITHOUT any separator
    private val miPrefix = Regex("(می|نمی)(?!\u200C)([آابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی])")

    override fun process(text: String): String =
        text.replace(miPrefix) { match ->
            "${match.groupValues[1]}\u200C${match.groupValues[2]}"
        }
}

/**
 * Normalizes the ezafe connector ـِ (kasra) when written as a raw ِ
 * after a word to the ZWNJ+ی form that TTS handles more naturally.
 *
 * e.g. "خانهِ" → "خانه‌ی"
 */
class EzafeNormalizationRule @Inject constructor() : GrammarRule {
    // Word ending in هـ followed by kasra (U+0650)
    private val ezafePattern = Regex("(ه)\u0650")

    override fun process(text: String): String =
        text.replace(ezafePattern, "ه‌ی")
}
