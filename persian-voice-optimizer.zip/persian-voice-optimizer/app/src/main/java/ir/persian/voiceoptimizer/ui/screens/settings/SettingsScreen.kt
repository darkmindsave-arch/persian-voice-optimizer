package ir.persian.voiceoptimizer.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

data class AppSettings(
    val normalizeDigits: Boolean = true,
    val normalizeArabicChars: Boolean = true,
    val expandAbbreviations: Boolean = true,
    val fixVerbPrefixes: Boolean = true,
    val replaceUrls: Boolean = true,
    val expandEnglishAbbreviations: Boolean = true,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("تنظیمات", style = MaterialTheme.typography.titleLarge) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "برگشت")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                    )
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                SectionHeader("قوانین تایپوگرافی")
                SettingsCard {
                    SettingRow(
                        title = "تبدیل کاراکترهای عربی به فارسی",
                        subtitle = "ك → ک   ي → ی",
                        checked = true,
                        onToggle = {},
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 12.dp))
                    SettingRow(
                        title = "نرمال‌سازی اعداد فارسی",
                        subtitle = "۱۲۳ → 123",
                        checked = true,
                        onToggle = {},
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 12.dp))
                    SettingRow(
                        title = "اصلاح فاصله‌گذاری نقطه‌گذاری",
                        subtitle = "حذف فاصله قبل از علائم",
                        checked = true,
                        onToggle = {},
                    )
                }

                SectionHeader("قوانین دستور زبان")
                SettingsCard {
                    SettingRow(
                        title = "افزودن نیم‌فاصله بعد از «می»",
                        subtitle = "میرود → می‌رود",
                        checked = true,
                        onToggle = {},
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 12.dp))
                    SettingRow(
                        title = "نرمال‌سازی اضافه",
                        subtitle = "خانهِ → خانه‌ی",
                        checked = true,
                        onToggle = {},
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 12.dp))
                    SettingRow(
                        title = "بسط اختصارات",
                        subtitle = "ص. → صفحه‌ی",
                        checked = true,
                        onToggle = {},
                    )
                }

                SectionHeader("قوانین TTS")
                SettingsCard {
                    SettingRow(
                        title = "جایگزینی لینک‌ها",
                        subtitle = "https://... → (لینک)",
                        checked = true,
                        onToggle = {},
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 12.dp))
                    SettingRow(
                        title = "بسط مخفف‌های انگلیسی",
                        subtitle = "AI → هوش مصنوعی",
                        checked = true,
                        onToggle = {},
                    )
                }

                // App info
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Column {
                            Text("بهینه‌ساز صوتی فارسی", style = MaterialTheme.typography.bodyLarge)
                            Text("نسخه 0.1.0 — آفلاین، بدون تبلیغ، بدون ردیابی",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(vertical = 4.dp),
    )
}

@Composable
private fun SettingsCard(content: @Composable Column.() -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            content()
        }
    }
}

@Composable
private fun SettingRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onToggle: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Switch(checked = checked, onCheckedChange = onToggle)
    }
}
