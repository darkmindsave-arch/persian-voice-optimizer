package ir.persian.voiceoptimizer.epub.writer

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import ir.persian.voiceoptimizer.epub.parser.EpubBook
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import javax.inject.Inject

/**
 * Rebuilds a processed [EpubBook] into a valid EPUB ZIP file and
 * returns a [Uri] (via FileProvider) that can be shared or opened.
 *
 * Write order follows EPUB spec:
 * 1. mimetype (uncompressed, first entry)
 * 2. META-INF/container.xml
 * 3. OPF
 * 4. All chapters
 * 5. Remaining assets
 */
class EpubWriter @Inject constructor(
    private val context: Context,
) {
    fun write(book: EpubBook, originalName: String): Uri {
        val outputDir = File(context.filesDir, "epub_output").also { it.mkdirs() }
        val outputFile = File(outputDir, buildOutputName(originalName))

        ZipOutputStream(outputFile.outputStream().buffered()).use { zip ->
            // 1. mimetype — MUST be first, uncompressed
            zip.putNextEntry(ZipEntry("mimetype").also { it.method = ZipEntry.STORED; it.size = MIMETYPE_BYTES.size.toLong(); it.crc = computeCrc(MIMETYPE_BYTES) })
            zip.write(MIMETYPE_BYTES)
            zip.closeEntry()

            // 2. container.xml
            writeText(zip, "META-INF/container.xml", book.containerXml)

            // 3. OPF
            writeText(zip, book.opfPath, book.opfContent)

            // 4. Chapters
            book.chapters.forEach { chapter ->
                writeText(zip, chapter.href, chapter.originalHtml)
            }

            // 5. Remaining assets (CSS, images, NCX, nav, fonts…)
            book.assets.forEach { (path, bytes) ->
                if (path == "mimetype") return@forEach // already written
                zip.putNextEntry(ZipEntry(path))
                zip.write(bytes)
                zip.closeEntry()
            }
        }

        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            outputFile,
        )
    }

    private fun writeText(zip: ZipOutputStream, path: String, content: String) {
        val bytes = content.toByteArray(Charsets.UTF_8)
        zip.putNextEntry(ZipEntry(path))
        zip.write(bytes)
        zip.closeEntry()
    }

    private fun buildOutputName(originalName: String): String {
        val base = originalName.removeSuffix(".epub")
        return "${base}_optimized.epub"
    }

    private fun computeCrc(bytes: ByteArray): Long {
        val crc = java.util.zip.CRC32()
        crc.update(bytes)
        return crc.value
    }

    companion object {
        private val MIMETYPE_BYTES = "application/epub+zip".toByteArray(Charsets.US_ASCII)
    }
}
