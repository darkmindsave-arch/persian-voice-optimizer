package ir.persian.voiceoptimizer.core.di

import android.content.Context
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import ir.persian.voiceoptimizer.epub.parser.EpubParser
import ir.persian.voiceoptimizer.epub.writer.EpubWriter
import ir.persian.voiceoptimizer.processor.TextProcessor
import ir.persian.voiceoptimizer.rules.diacritics.SmartDiacriticsRule
import ir.persian.voiceoptimizer.rules.grammar.AbbreviationExpansionRule
import ir.persian.voiceoptimizer.rules.grammar.EzafeNormalizationRule
import ir.persian.voiceoptimizer.rules.grammar.StripRawDiacriticsRule
import ir.persian.voiceoptimizer.rules.grammar.VerbPrefixZwnjRule
import ir.persian.voiceoptimizer.rules.humanize.DashPauseRule
import ir.persian.voiceoptimizer.rules.humanize.DialoguePauseRule
import ir.persian.voiceoptimizer.rules.humanize.EllipsisPauseRule
import ir.persian.voiceoptimizer.rules.humanize.SubordinateClausePauseRule
import ir.persian.voiceoptimizer.rules.tts.EnglishAbbreviationRule
import ir.persian.voiceoptimizer.rules.tts.HtmlEntityCleanupRule
import ir.persian.voiceoptimizer.rules.tts.SentenceBoundaryRule
import ir.persian.voiceoptimizer.rules.tts.UrlReplacementRule
import ir.persian.voiceoptimizer.rules.typography.ArabicToFarsiCharRule
import ir.persian.voiceoptimizer.rules.typography.PersianDigitNormalizationRule
import ir.persian.voiceoptimizer.rules.typography.PunctuationSpacingRule
import ir.persian.voiceoptimizer.rules.typography.WhitespaceNormalizationRule
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideEpubParser(@ApplicationContext ctx: Context): EpubParser = EpubParser(ctx)

    @Provides
    @Singleton
    fun provideEpubWriter(@ApplicationContext ctx: Context): EpubWriter = EpubWriter(ctx)

    @Provides
    @Singleton
    fun provideTextProcessor(): TextProcessor = TextProcessor(
        arabicToFarsiCharRule = ArabicToFarsiCharRule(),
        whitespaceNormalizationRule = WhitespaceNormalizationRule(),
        punctuationSpacingRule = PunctuationSpacingRule(),
        persianDigitNormalizationRule = PersianDigitNormalizationRule(),
        abbreviationExpansionRule = AbbreviationExpansionRule(),
        stripRawDiacriticsRule = StripRawDiacriticsRule(),
        verbPrefixZwnjRule = VerbPrefixZwnjRule(),
        ezafeNormalizationRule = EzafeNormalizationRule(),
        sentenceBoundaryRule = SentenceBoundaryRule(),
        urlReplacementRule = UrlReplacementRule(),
        englishAbbreviationRule = EnglishAbbreviationRule(),
        htmlEntityCleanupRule = HtmlEntityCleanupRule(),
        subordinateClausePauseRule = SubordinateClausePauseRule(),
        dashPauseRule = DashPauseRule(),
        ellipsisPauseRule = EllipsisPauseRule(),
        dialoguePauseRule = DialoguePauseRule(),
        smartDiacriticsRule = SmartDiacriticsRule(),
    )
}
