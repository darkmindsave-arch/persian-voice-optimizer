package ir.persian.voiceoptimizer.processor

import ir.persian.voiceoptimizer.core.domain.model.OptimizationMode
import ir.persian.voiceoptimizer.core.domain.model.ProcessingOptions
import ir.persian.voiceoptimizer.rules.TextRule
import ir.persian.voiceoptimizer.rules.diacritics.SmartDiacriticsRule
import ir.persian.voiceoptimizer.rules.grammar.AbbreviationExpansionRule
import ir.persian.voiceoptimizer.rules.grammar.EzafeNormalizationRule
import ir.persian.voiceoptimizer.rules.grammar.StripRawDiacriticsRule
import ir.persian.voiceoptimizer.rules.grammar.VerbPrefixZwnjRule
import ir.persian.voiceoptimizer.rules.humanize.DashPauseRule
import ir.persian.voiceoptimizer.rules.humanize.DialoguePauseRule
import ir.persian.voiceoptimizer.rules.humanize.EllipsisPauseRule
import ir.persian.voiceoptimizer.rules.humanize.SubordinateClausePauseRule
import ir.persian.voiceoptimizer.rules.tts.EnglishAbbreviationRule
import ir.persian.voiceoptimizer.rules.tts.HtmlEntityCleanupRule
import ir.persian.voiceoptimizer.rules.tts.SentenceBoundaryRule
import ir.persian.voiceoptimizer.rules.tts.UrlReplacementRule
import ir.persian.voiceoptimizer.rules.typography.ArabicToFarsiCharRule
import ir.persian.voiceoptimizer.rules.typography.PersianDigitNormalizationRule
import ir.persian.voiceoptimizer.rules.typography.PunctuationSpacingRule
import ir.persian.voiceoptimizer.rules.typography.WhitespaceNormalizationRule
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.TextNode
import javax.inject.Inject

/**
 * Applies an ordered pipeline of [TextRule]s to the text nodes of an XHTML document,
 * leaving all HTML tags, attributes, CSS, and structure untouched.
 *
 * Rule execution order per mode:
 * NORMAL       → Typography
 * NATURAL      → Typography + Grammar + TTS
 * HUMAN_VOICE  → Typography + Grammar + TTS + Humanize [+ Diacritics if opted-in]
 */
class TextProcessor @Inject constructor(
    // Typography
    private val arabicToFarsiCharRule: ArabicToFarsiCharRule,
    private val whitespaceNormalizationRule: WhitespaceNormalizationRule,
    private val punctuationSpacingRule: PunctuationSpacingRule,
    private val persianDigitNormalizationRule: PersianDigitNormalizationRule,
    // Grammar
    private val abbreviationExpansionRule: AbbreviationExpansionRule,
    private val stripRawDiacriticsRule: StripRawDiacriticsRule,
    private val verbPrefixZwnjRule: VerbPrefixZwnjRule,
    private val ezafeNormalizationRule: EzafeNormalizationRule,
    // TTS
    private val sentenceBoundaryRule: SentenceBoundaryRule,
    private val urlReplacementRule: UrlReplacementRule,
    private val englishAbbreviationRule: EnglishAbbreviationRule,
    private val htmlEntityCleanupRule: HtmlEntityCleanupRule,
    // Humanize
    private val subordinateClausePauseRule: SubordinateClausePauseRule,
    private val dashPauseRule: DashPauseRule,
    private val ellipsisPauseRule: EllipsisPauseRule,
    private val dialoguePauseRule: DialoguePauseRule,
    // Diacritics
    private val smartDiacriticsRule: SmartDiacriticsRule,
) {
    fun process(xhtml: String, options: ProcessingOptions): String {
        val pipeline = buildPipeline(options)
        if (pipeline.isEmpty()) return xhtml

        val doc: Document = Jsoup.parse(xhtml, "", org.jsoup.parser.Parser.xmlParser())
        doc.outputSettings()
            .syntax(Document.OutputSettings.Syntax.xml)
            .charset(Charsets.UTF_8)
            .prettyPrint(false)

        // Walk only TextNodes — leave all tags/attributes intact
        doc.body()?.let { body ->
            walkTextNodes(body, pipeline)
        } ?: walkTextNodes(doc, pipeline)

        return doc.outerHtml()
    }

    private fun walkTextNodes(node: org.jsoup.nodes.Node, pipeline: List<TextRule>) {
        node.childNodes().forEach { child ->
            when (child) {
                is TextNode -> {
                    val original = child.wholeText
                    val processed = pipeline.fold(original) { acc, rule -> rule.process(acc) }
                    if (processed != original) child.text(processed)
                }
                else -> walkTextNodes(child, pipeline)
            }
        }
    }

    private fun buildPipeline(options: ProcessingOptions): List<TextRule> = buildList {
        // Always applied: typography baseline
        add(arabicToFarsiCharRule)
        add(whitespaceNormalizationRule)
        add(punctuationSpacingRule)
        add(persianDigitNormalizationRule)

        if (options.mode >= OptimizationMode.NATURAL) {
            // Grammar
            if (!options.enableSmartDiacritics) {
                add(stripRawDiacriticsRule)
            }
            add(abbreviationExpansionRule)
            add(verbPrefixZwnjRule)
            add(ezafeNormalizationRule)
            // TTS
            add(htmlEntityCleanupRule)
            add(urlReplacementRule)
            add(englishAbbreviationRule)
            add(sentenceBoundaryRule)
        }

        if (options.mode >= OptimizationMode.HUMAN_VOICE) {
            add(ellipsisPauseRule)
            add(dashPauseRule)
            add(subordinateClausePauseRule)
            add(dialoguePauseRule)
        }

        // Smart diacritics — last in pipeline, any mode
        if (options.enableSmartDiacritics) {
            add(smartDiacriticsRule)
        }
    }
}

private operator fun OptimizationMode.compareTo(other: OptimizationMode): Int =
    this.ordinal.compareTo(other.ordinal)
