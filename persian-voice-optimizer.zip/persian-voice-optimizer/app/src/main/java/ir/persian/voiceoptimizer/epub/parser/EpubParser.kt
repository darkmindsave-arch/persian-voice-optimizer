package ir.persian.voiceoptimizer.epub.parser

import android.content.Context
import android.net.Uri
import ir.persian.voiceoptimizer.core.domain.model.EpubChapter
import org.jsoup.Jsoup
import org.jsoup.parser.Parser
import java.io.InputStream
import java.util.zip.ZipInputStream
import javax.inject.Inject

/**
 * Parses an EPUB (ZIP) file from a content [Uri] into an [EpubBook].
 *
 * Strategy:
 * 1. Read every ZIP entry into memory (assets map).
 * 2. Locate META-INF/container.xml → find OPF path.
 * 3. Parse OPF spine → ordered list of XHTML hrefs.
 * 4. Wrap each XHTML entry as an [EpubChapter].
 */
class EpubParser @Inject constructor(
    private val context: Context,
) {
    fun parse(uri: Uri): EpubBook {
        val assets = mutableMapOf<String, ByteArray>()

        openStream(uri).use { stream ->
            ZipInputStream(stream).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        assets[entry.name] = zip.readBytes()
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }

        val containerXml = assets["META-INF/container.xml"]?.decodeToString()
            ?: throw IllegalArgumentException("META-INF/container.xml not found — not a valid EPUB")

        val opfPath = extractOpfPath(containerXml)
        val opfContent = assets[opfPath]?.decodeToString()
            ?: throw IllegalArgumentException("OPF file not found at $opfPath")

        val opfDir = opfPath.substringBeforeLast('/', "")
        val spineHrefs = extractSpineHrefs(opfContent, opfDir)

        val chapters = spineHrefs.mapIndexed { index, href ->
            val zipKey = if (opfDir.isEmpty()) href else "$opfDir/$href"
            val html = assets[zipKey]?.decodeToString()
                ?: throw IllegalArgumentException("Spine item not found in ZIP: $zipKey")
            EpubChapter(id = "chapter_$index", href = zipKey, originalHtml = html)
        }

        // Remove chapter entries from assets — they are handled separately
        chapters.forEach { assets.remove(it.href) }

        return EpubBook(
            chapters = chapters,
            assets = assets,
            opfContent = opfContent,
            opfPath = opfPath,
            containerXml = containerXml,
        )
    }

    private fun openStream(uri: Uri): InputStream =
        context.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("Cannot open URI: $uri")

    private fun extractOpfPath(containerXml: String): String {
        val doc = Jsoup.parse(containerXml, "", Parser.xmlParser())
        return doc.selectFirst("rootfile[full-path]")
            ?.attr("full-path")
            ?: throw IllegalArgumentException("No rootfile element in container.xml")
    }

    /**
     * Parses the OPF <spine> to retrieve ordered XHTML hrefs from <manifest>.
     * Returns hrefs relative to the OPF directory.
     */
    private fun extractSpineHrefs(opfContent: String, opfDir: String): List<String> {
        val doc = Jsoup.parse(opfContent, "", Parser.xmlParser())

        // Build idref → href map from manifest
        val manifest = doc.select("manifest > item").associate { item ->
            item.attr("id") to item.attr("href")
        }

        // Walk spine itemrefs in order
        return doc.select("spine > itemref").mapNotNull { itemref ->
            val idref = itemref.attr("idref")
            manifest[idref]
        }
    }
}
