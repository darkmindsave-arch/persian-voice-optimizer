package ir.persian.voiceoptimizer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import dagger.hilt.android.AndroidEntryPoint
import ir.persian.voiceoptimizer.ui.theme.PersianVoiceOptimizerTheme
import ir.persian.voiceoptimizer.ui.AppNavGraph

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PersianVoiceOptimizerTheme {
                AppNavGraph()
            }
        }
    }
}
