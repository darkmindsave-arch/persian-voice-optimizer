package ir.persian.voiceoptimizer.core.domain.usecase

import ir.persian.voiceoptimizer.core.domain.model.EpubFile
import ir.persian.voiceoptimizer.core.domain.model.ProcessingOptions
import ir.persian.voiceoptimizer.core.domain.model.ProcessingResult
import ir.persian.voiceoptimizer.epub.parser.EpubParser
import ir.persian.voiceoptimizer.epub.writer.EpubWriter
import ir.persian.voiceoptimizer.processor.TextProcessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import org.jsoup.Jsoup
import javax.inject.Inject

private const val PREVIEW_CHAR_LIMIT = 600

/**
 * Orchestrates: parse → process each chapter → rebuild EPUB.
 * Emits [ProcessingResult] events for live UI progress.
 * On success, includes a short plain-text excerpt for PreviewScreen.
 */
class ProcessEpubUseCase @Inject constructor(
    private val parser: EpubParser,
    private val writer: EpubWriter,
    private val textProcessor: TextProcessor,
) {
    operator fun invoke(
        epub: EpubFile,
        options: ProcessingOptions,
    ): Flow<ProcessingResult> = flow {
        emit(ProcessingResult.Progress(0, "باز کردن فایل EPUB…"))

        val book = runCatching { parser.parse(epub.uri) }.getOrElse { e ->
            emit(ProcessingResult.Failure(e))
            return@flow
        }

        val total = book.chapters.size.coerceAtLeast(1)

        // Capture first-chapter plain text before processing for preview
        val previewOriginal = book.chapters.firstOrNull()
            ?.let { extractPlainText(it.originalHtml) }
            ?.take(PREVIEW_CHAR_LIMIT)
            ?: ""

        val processedChapters = book.chapters.mapIndexed { index, chapter ->
            val processedHtml = textProcessor.process(chapter.originalHtml, options)
            val percent = ((index + 1) * 90) / total
            emit(ProcessingResult.Progress(percent, "فصل ${index + 1} از $total"))
            chapter.copy(originalHtml = processedHtml)
        }

        val previewProcessed = processedChapters.firstOrNull()
            ?.let { extractPlainText(it.originalHtml) }
            ?.take(PREVIEW_CHAR_LIMIT)
            ?: ""

        emit(ProcessingResult.Progress(95, "بازسازی EPUB…"))

        val outputUri = runCatching {
            writer.write(book.copy(chapters = processedChapters), epub.name)
        }.getOrElse { e ->
            emit(ProcessingResult.Failure(e))
            return@flow
        }

        emit(ProcessingResult.Progress(100, "انجام شد"))
        emit(ProcessingResult.Success(
            outputUri = outputUri,
            chaptersProcessed = processedChapters.size,
            previewOriginal = previewOriginal,
            previewProcessed = previewProcessed,
        ))
    }.flowOn(Dispatchers.IO)

    private fun extractPlainText(xhtml: String): String =
        Jsoup.parse(xhtml).body()?.text() ?: ""
}
