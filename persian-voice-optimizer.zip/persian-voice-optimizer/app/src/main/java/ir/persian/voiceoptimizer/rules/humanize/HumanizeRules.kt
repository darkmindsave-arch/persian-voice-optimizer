package ir.persian.voiceoptimizer.rules.humanize

import ir.persian.voiceoptimizer.rules.HumanizeRule
import javax.inject.Inject

/**
 * Inserts a soft pause marker (،) after long subordinate clauses introduced
 * by conjunctions like "که", "چون", "اگر", "وقتی", "تا".
 * This prevents monotone run-on delivery in TTS.
 *
 * Heuristic: clause > 6 words before the next sentence-final punctuation.
 */
class SubordinateClausePauseRule @Inject constructor() : HumanizeRule {
    // Conjunction followed by 6+ word characters before end of sentence
    private val longClause = Regex(
        "(\\b(?:که|چون|اگر|وقتی|تا|زیرا|هرچند|اگرچه)\\b" +
            "(?:\\s+\\S+){6,}?)(?=[،؟!.؛])"
    )

    override fun process(text: String): String =
        text.replace(longClause) { match -> "${match.value}،" }
}

/**
 * Adds "…" after dash-introduced phrases (em dash or en dash) to cue
 * a natural pause, mimicking how a reader would pause at a parenthetical.
 */
class DashPauseRule @Inject constructor() : HumanizeRule {
    private val dashPhrase = Regex("([—–])([^—–\n]{3,30}?)([—–])")

    override fun process(text: String): String =
        text.replace(dashPhrase) { match ->
            "،${match.groupValues[2]}،"
        }
}

/**
 * Replaces ellipsis characters (… or ...) with a comma + space
 * so TTS engines pause naturally instead of reading "dot dot dot".
 */
class EllipsisPauseRule @Inject constructor() : HumanizeRule {
    private val ellipsis = Regex("…|\\.{3}")

    override fun process(text: String): String =
        text.replace(ellipsis, "، ")
}

/**
 * Adds a slight pause (comma) before direct speech markers "گفت", "پرسید", "افزود"
 * when they follow a closing quotation mark to naturalise dialogue delivery.
 */
class DialoguePauseRule @Inject constructor() : HumanizeRule {
    private val dialogueTag = Regex("(\"\\s*)(?=(گفت|پرسید|افزود|خندید|فریاد زد))")

    override fun process(text: String): String =
        text.replace(dialogueTag, "$1، ")
}
