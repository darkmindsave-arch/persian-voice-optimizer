package ir.persian.voiceoptimizer.epub.parser

import ir.persian.voiceoptimizer.core.domain.model.EpubChapter

/**
 * In-memory representation of a parsed EPUB.
 * All binary assets (images, CSS, fonts) are kept as raw byte arrays
 * so the writer can reconstruct the ZIP without data loss.
 */
data class EpubBook(
    /** Spine-ordered list of XHTML chapters. */
    val chapters: List<EpubChapter>,
    /** Raw bytes of every non-chapter entry, keyed by ZIP path. */
    val assets: Map<String, ByteArray>,
    /** OPF XML source (pre-parsed for metadata, re-written verbatim). */
    val opfContent: String,
    /** Relative path of the OPF file inside the ZIP (e.g. "OEBPS/content.opf"). */
    val opfPath: String,
    /** container.xml content — written back unchanged. */
    val containerXml: String,
)
