package ir.persian.voiceoptimizer.rules

import ir.persian.voiceoptimizer.rules.tts.EnglishAbbreviationRule
import ir.persian.voiceoptimizer.rules.tts.HtmlEntityCleanupRule
import ir.persian.voiceoptimizer.rules.tts.SentenceBoundaryRule
import ir.persian.voiceoptimizer.rules.tts.UrlReplacementRule
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TtsRulesTest {

    private val sentenceBoundary = SentenceBoundaryRule()
    private val urlReplacement = UrlReplacementRule()
    private val englishAbbreviation = EnglishAbbreviationRule()
    private val htmlEntity = HtmlEntityCleanupRule()

    @Test
    fun `UrlReplacementRule replaces http URL`() {
        val input = "برای اطلاعات بیشتر به https://example.com مراجعه کنید"
        val result = urlReplacement.process(input)
        assertFalse(result.contains("https://"))
        assertTrue(result.contains("(لینک)"))
    }

    @Test
    fun `UrlReplacementRule replaces email address`() {
        val input = "به info@example.com ایمیل بزنید"
        val result = urlReplacement.process(input)
        assertFalse(result.contains("@"))
        assertTrue(result.contains("(ایمیل)"))
    }

    @Test
    fun `EnglishAbbreviationRule expands AI`() {
        val input = "این یک پروژه AI است"
        val result = englishAbbreviation.process(input)
        assertTrue(result.contains("هوش مصنوعی"))
    }

    @Test
    fun `EnglishAbbreviationRule expands API`() {
        val input = "از API استفاده کنید"
        val result = englishAbbreviation.process(input)
        assertTrue(result.contains("رابط برنامه‌نویسی"))
    }

    @Test
    fun `HtmlEntityCleanupRule replaces nbsp`() {
        val input = "متن&nbsp;جدید"
        val result = htmlEntity.process(input)
        assertFalse(result.contains("&nbsp;"))
    }

    @Test
    fun `HtmlEntityCleanupRule removes unknown entities`() {
        val input = "متن&unknown;چیزی"
        val result = htmlEntity.process(input)
        assertFalse(result.contains("&unknown;"))
    }

    @Test
    fun `SentenceBoundaryRule replaces multiple dots with ellipsis`() {
        val input = "صبر کن..."
        val result = sentenceBoundary.process(input)
        assertTrue(result.contains("…"))
        assertFalse(result.contains("..."))
    }
}
