package ir.persian.voiceoptimizer.rules

import ir.persian.voiceoptimizer.rules.grammar.AbbreviationExpansionRule
import ir.persian.voiceoptimizer.rules.grammar.EzafeNormalizationRule
import ir.persian.voiceoptimizer.rules.grammar.StripRawDiacriticsRule
import ir.persian.voiceoptimizer.rules.grammar.VerbPrefixZwnjRule
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GrammarRulesTest {

    private val abbreviation = AbbreviationExpansionRule()
    private val stripDiacritics = StripRawDiacriticsRule()
    private val verbPrefix = VerbPrefixZwnjRule()
    private val ezafe = EzafeNormalizationRule()

    @Test
    fun `StripRawDiacriticsRule removes fathah`() {
        val input = "کِتَاب"
        val result = stripDiacritics.process(input)
        assertFalse(result.contains('\u0650')) // kasra
        assertFalse(result.contains('\u064E')) // fathah
    }

    @Test
    fun `StripRawDiacriticsRule removes tatweel`() {
        val input = "کتـاب"
        val result = stripDiacritics.process(input)
        assertFalse(result.contains('\u0640'))
    }

    @Test
    fun `VerbPrefixZwnjRule inserts ZWNJ after می`() {
        val input = "میرود"
        val result = verbPrefix.process(input)
        assertTrue(result.contains("می\u200Cر"))
    }

    @Test
    fun `VerbPrefixZwnjRule inserts ZWNJ after نمی`() {
        val input = "نمیخواهد"
        val result = verbPrefix.process(input)
        assertTrue(result.contains("نمی\u200Cخ"))
    }

    @Test
    fun `VerbPrefixZwnjRule is idempotent`() {
        val input = "می\u200Cرود"
        assertEquals(input, verbPrefix.process(input))
    }

    @Test
    fun `EzafeNormalizationRule converts kasra ezafe`() {
        val input = "خانه\u0650"
        val expected = "خانه‌ی"
        assertEquals(expected, ezafe.process(input))
    }

    @Test
    fun `AbbreviationExpansionRule expands ص dot`() {
        val input = "ص. ۴۵"
        val result = abbreviation.process(input)
        assertTrue(result.contains("صفحه‌ی"))
    }
}
