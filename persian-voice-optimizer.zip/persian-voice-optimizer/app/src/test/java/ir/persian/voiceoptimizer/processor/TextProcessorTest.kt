package ir.persian.voiceoptimizer.processor

import ir.persian.voiceoptimizer.core.domain.model.OptimizationMode
import ir.persian.voiceoptimizer.core.domain.model.ProcessingOptions
import ir.persian.voiceoptimizer.rules.diacritics.SmartDiacriticsRule
import ir.persian.voiceoptimizer.rules.grammar.AbbreviationExpansionRule
import ir.persian.voiceoptimizer.rules.grammar.EzafeNormalizationRule
import ir.persian.voiceoptimizer.rules.grammar.StripRawDiacriticsRule
import ir.persian.voiceoptimizer.rules.grammar.VerbPrefixZwnjRule
import ir.persian.voiceoptimizer.rules.humanize.DashPauseRule
import ir.persian.voiceoptimizer.rules.humanize.DialoguePauseRule
import ir.persian.voiceoptimizer.rules.humanize.EllipsisPauseRule
import ir.persian.voiceoptimizer.rules.humanize.SubordinateClausePauseRule
import ir.persian.voiceoptimizer.rules.tts.EnglishAbbreviationRule
import ir.persian.voiceoptimizer.rules.tts.HtmlEntityCleanupRule
import ir.persian.voiceoptimizer.rules.tts.SentenceBoundaryRule
import ir.persian.voiceoptimizer.rules.tts.UrlReplacementRule
import ir.persian.voiceoptimizer.rules.typography.ArabicToFarsiCharRule
import ir.persian.voiceoptimizer.rules.typography.PersianDigitNormalizationRule
import ir.persian.voiceoptimizer.rules.typography.PunctuationSpacingRule
import ir.persian.voiceoptimizer.rules.typography.WhitespaceNormalizationRule
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class TextProcessorTest {

    private lateinit var processor: TextProcessor

    @Before
    fun setUp() {
        processor = TextProcessor(
            arabicToFarsiCharRule = ArabicToFarsiCharRule(),
            whitespaceNormalizationRule = WhitespaceNormalizationRule(),
            punctuationSpacingRule = PunctuationSpacingRule(),
            persianDigitNormalizationRule = PersianDigitNormalizationRule(),
            abbreviationExpansionRule = AbbreviationExpansionRule(),
            stripRawDiacriticsRule = StripRawDiacriticsRule(),
            verbPrefixZwnjRule = VerbPrefixZwnjRule(),
            ezafeNormalizationRule = EzafeNormalizationRule(),
            sentenceBoundaryRule = SentenceBoundaryRule(),
            urlReplacementRule = UrlReplacementRule(),
            englishAbbreviationRule = EnglishAbbreviationRule(),
            htmlEntityCleanupRule = HtmlEntityCleanupRule(),
            subordinateClausePauseRule = SubordinateClausePauseRule(),
            dashPauseRule = DashPauseRule(),
            ellipsisPauseRule = EllipsisPauseRule(),
            dialoguePauseRule = DialoguePauseRule(),
            smartDiacriticsRule = SmartDiacriticsRule(),
        )
    }

    @Test
    fun `NORMAL mode converts Arabic chars in text nodes`() {
        val xhtml = """
            <?xml version="1.0" encoding="utf-8"?>
            <html xmlns="http://www.w3.org/1999/xhtml">
            <body><p>كتاب يك</p></body>
            </html>
        """.trimIndent()

        val result = processor.process(xhtml, ProcessingOptions(mode = OptimizationMode.NORMAL))
        assertTrue("Arabic kaf should be replaced", result.contains("کتاب"))
        assertTrue("Arabic yeh should be replaced", result.contains("یک"))
    }

    @Test
    fun `NORMAL mode leaves HTML tags untouched`() {
        val xhtml = """
            <?xml version="1.0" encoding="utf-8"?>
            <html xmlns="http://www.w3.org/1999/xhtml">
            <body><p class="chapter-title" id="ch1">سلام</p></body>
            </html>
        """.trimIndent()

        val result = processor.process(xhtml, ProcessingOptions(mode = OptimizationMode.NORMAL))
        assertTrue("class attribute must survive", result.contains("chapter-title"))
        assertTrue("id attribute must survive", result.contains("ch1"))
    }

    @Test
    fun `NATURAL mode adds ZWNJ after می prefix`() {
        val xhtml = """
            <?xml version="1.0" encoding="utf-8"?>
            <html xmlns="http://www.w3.org/1999/xhtml">
            <body><p>او میرود به خانه</p></body>
            </html>
        """.trimIndent()

        val result = processor.process(xhtml, ProcessingOptions(mode = OptimizationMode.NATURAL))
        assertTrue("ZWNJ must be inserted after می", result.contains("می\u200Cر"))
    }

    @Test
    fun `NATURAL mode replaces URLs`() {
        val xhtml = """
            <?xml version="1.0" encoding="utf-8"?>
            <html xmlns="http://www.w3.org/1999/xhtml">
            <body><p>به https://example.com مراجعه کنید</p></body>
            </html>
        """.trimIndent()

        val result = processor.process(xhtml, ProcessingOptions(mode = OptimizationMode.NATURAL))
        assertFalse("URL must be removed", result.contains("https://"))
        assertTrue("Placeholder must appear", result.contains("(لینک)"))
    }

    @Test
    fun `NATURAL mode does not apply humanize rules`() {
        // EllipsisPauseRule only runs in HUMAN_VOICE
        val xhtml = """
            <?xml version="1.0" encoding="utf-8"?>
            <html xmlns="http://www.w3.org/1999/xhtml">
            <body><p>صبر کن...</p></body>
            </html>
        """.trimIndent()

        val result = processor.process(xhtml, ProcessingOptions(mode = OptimizationMode.NATURAL))
        // In NATURAL mode, SentenceBoundaryRule replaces ... with … but EllipsisPauseRule (،) does not run
        assertFalse("Ellipsis pause rule must not run in NATURAL", result.contains("، "))
    }

    @Test
    fun `HUMAN_VOICE mode applies ellipsis pause rule`() {
        val xhtml = """
            <?xml version="1.0" encoding="utf-8"?>
            <html xmlns="http://www.w3.org/1999/xhtml">
            <body><p>صبر کن…</p></body>
            </html>
        """.trimIndent()

        val result = processor.process(xhtml, ProcessingOptions(mode = OptimizationMode.HUMAN_VOICE))
        assertTrue("Ellipsis should become comma-pause in HUMAN_VOICE", result.contains("، "))
    }

    @Test
    fun `Smart diacritics mode adds diacritized است`() {
        val xhtml = """
            <?xml version="1.0" encoding="utf-8"?>
            <html xmlns="http://www.w3.org/1999/xhtml">
            <body><p>این خوب است</p></body>
            </html>
        """.trimIndent()

        val result = processor.process(
            xhtml,
            ProcessingOptions(mode = OptimizationMode.NATURAL, enableSmartDiacritics = true)
        )
        assertTrue("است should be diacritized", result.contains("اَست"))
    }

    @Test
    fun `Processor preserves XML declaration and namespace`() {
        val xhtml = """<?xml version="1.0" encoding="utf-8"?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>فصل اول</title></head>
<body><p>متن</p></body>
</html>"""

        val result = processor.process(xhtml, ProcessingOptions(mode = OptimizationMode.NORMAL))
        assertTrue("Title tag must survive", result.contains("<title>"))
        assertTrue("Body tag must survive", result.contains("<body>"))
    }

    @Test
    fun `Processor is idempotent on clean Persian text`() {
        val xhtml = """
            <?xml version="1.0" encoding="utf-8"?>
            <html xmlns="http://www.w3.org/1999/xhtml">
            <body><p>کتاب خوب است.</p></body>
            </html>
        """.trimIndent()

        val options = ProcessingOptions(mode = OptimizationMode.NORMAL)
        val once = processor.process(xhtml, options)
        val twice = processor.process(once, options)
        // Text content must be identical after second pass
        assertTrue(
            "Second pass must not alter already-normalized text",
            once.contains("کتاب") && twice.contains("کتاب")
        )
    }

    @Test
    fun `Persian digits normalized in NORMAL mode`() {
        val xhtml = """
            <?xml version="1.0" encoding="utf-8"?>
            <html xmlns="http://www.w3.org/1999/xhtml">
            <body><p>صفحه ۱۲۳</p></body>
            </html>
        """.trimIndent()

        val result = processor.process(xhtml, ProcessingOptions(mode = OptimizationMode.NORMAL))
        assertTrue("Persian digits must become ASCII", result.contains("123"))
        assertFalse("Original Persian digits must be gone", result.contains("۱۲۳"))
    }
}
