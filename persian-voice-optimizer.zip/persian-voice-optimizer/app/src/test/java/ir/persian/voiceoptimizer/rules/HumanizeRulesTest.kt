package ir.persian.voiceoptimizer.rules

import ir.persian.voiceoptimizer.rules.humanize.DashPauseRule
import ir.persian.voiceoptimizer.rules.humanize.DialoguePauseRule
import ir.persian.voiceoptimizer.rules.humanize.EllipsisPauseRule
import ir.persian.voiceoptimizer.rules.humanize.SubordinateClausePauseRule
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HumanizeRulesTest {

    private val ellipsis = EllipsisPauseRule()
    private val dash = DashPauseRule()
    private val dialogue = DialoguePauseRule()
    private val clause = SubordinateClausePauseRule()

    @Test
    fun `EllipsisPauseRule replaces Unicode ellipsis`() {
        val input = "صبر کن… شاید"
        val result = ellipsis.process(input)
        assertFalse("Ellipsis char must be removed", result.contains("…"))
        assertTrue("Comma-pause must be inserted", result.contains("،"))
    }

    @Test
    fun `EllipsisPauseRule replaces three-dot ellipsis`() {
        val input = "ادامه دارد..."
        val result = ellipsis.process(input)
        assertFalse("Triple dot must be removed", result.contains("..."))
    }

    @Test
    fun `EllipsisPauseRule is idempotent`() {
        val input = "سلام… دنیا"
        val once = ellipsis.process(input)
        val twice = ellipsis.process(once)
        assertTrue("Second pass must not add more pauses", once == twice)
    }

    @Test
    fun `DashPauseRule wraps em-dash phrase with commas`() {
        val input = "او—با صدای بلند—گفت"
        val result = dash.process(input)
        assertFalse("Em-dash must be removed", result.contains("—"))
        assertTrue("Comma wrapping must be present", result.contains("،"))
    }

    @Test
    fun `DashPauseRule wraps en-dash phrase`() {
        val input = "رفت–آمد–نشست"
        val result = dash.process(input)
        assertFalse("En-dash must be removed", result.contains("–"))
    }

    @Test
    fun `DialoguePauseRule adds pause before گفت`() {
        val input = "\"برو\" گفت"
        val result = dialogue.process(input)
        assertTrue("Comma should appear before speech tag", result.contains("،"))
    }

    @Test
    fun `DialoguePauseRule adds pause before پرسید`() {
        val input = "\"چرا\" پرسید"
        val result = dialogue.process(input)
        assertTrue("Comma should appear before پرسید", result.contains("،"))
    }
}
