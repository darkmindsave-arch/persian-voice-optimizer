package ir.persian.voiceoptimizer.rules

import ir.persian.voiceoptimizer.rules.typography.ArabicToFarsiCharRule
import ir.persian.voiceoptimizer.rules.typography.PersianDigitNormalizationRule
import ir.persian.voiceoptimizer.rules.typography.PunctuationSpacingRule
import ir.persian.voiceoptimizer.rules.typography.WhitespaceNormalizationRule
import org.junit.Assert.assertEquals
import org.junit.Test

class TypographyRulesTest {

    private val arabicToFarsi = ArabicToFarsiCharRule()
    private val whitespace = WhitespaceNormalizationRule()
    private val punctuation = PunctuationSpacingRule()
    private val digits = PersianDigitNormalizationRule()

    @Test
    fun `ArabicToFarsiCharRule replaces Arabic kaf with Persian kaf`() {
        val input = "كتاب"
        val expected = "کتاب"
        assertEquals(expected, arabicToFarsi.process(input))
    }

    @Test
    fun `ArabicToFarsiCharRule replaces Arabic yeh with Persian yeh`() {
        val input = "يك"
        val expected = "یک"
        assertEquals(expected, arabicToFarsi.process(input))
    }

    @Test
    fun `ArabicToFarsiCharRule replaces Alef Maqsura with Persian yeh`() {
        val input = "علي"
        val expected = "علی"
        assertEquals(expected, arabicToFarsi.process(input))
    }

    @Test
    fun `ArabicToFarsiCharRule is idempotent`() {
        val input = "کتاب یک"
        assertEquals(input, arabicToFarsi.process(arabicToFarsi.process(input)))
    }

    @Test
    fun `WhitespaceNormalizationRule collapses multiple spaces`() {
        val input = "سلام    دنیا"
        val expected = "سلام دنیا"
        assertEquals(expected, whitespace.process(input))
    }

    @Test
    fun `WhitespaceNormalizationRule removes zero-width space`() {
        val input = "کتاب\u200Bخوب"
        val expected = "کتابخوب"
        assertEquals(expected, whitespace.process(input))
    }

    @Test
    fun `PunctuationSpacingRule removes space before comma`() {
        val input = "سلام ، دنیا"
        val expected = "سلام، دنیا"
        assertEquals(expected, punctuation.process(input))
    }

    @Test
    fun `PersianDigitNormalizationRule converts Eastern Arabic digits`() {
        val input = "٠١٢٣٤٥٦٧٨٩"
        val expected = "0123456789"
        assertEquals(expected, digits.process(input))
    }

    @Test
    fun `PersianDigitNormalizationRule converts Extended Arabic-Indic digits`() {
        val input = "۰۱۲۳۴۵۶۷۸۹"
        val expected = "0123456789"
        assertEquals(expected, digits.process(input))
    }
}
