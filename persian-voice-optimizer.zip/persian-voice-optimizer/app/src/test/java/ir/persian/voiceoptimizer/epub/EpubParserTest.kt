package ir.persian.voiceoptimizer.epub

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import ir.persian.voiceoptimizer.epub.parser.EpubParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.mockito.kotlin.any
import org.mockito.kotlin.mock
import org.mockito.kotlin.whenever
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class EpubParserTest {

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun buildMinimalEpub(
        chapterCount: Int = 2,
        chapterContent: String = "<html xmlns=\"http://www.w3.org/1999/xhtml\"><body><p>متن فصل</p></body></html>",
    ): ByteArray {
        val out = ByteArrayOutputStream()
        val zip = ZipOutputStream(out)

        // 1. mimetype (uncompressed)
        val mimeBytes = "application/epub+zip".toByteArray(Charsets.US_ASCII)
        zip.putNextEntry(ZipEntry("mimetype").also {
            it.method = ZipEntry.STORED
            it.size = mimeBytes.size.toLong()
            val crc = java.util.zip.CRC32().also { c -> c.update(mimeBytes) }
            it.crc = crc.value
        })
        zip.write(mimeBytes)
        zip.closeEntry()

        // 2. META-INF/container.xml
        zip.putNextEntry(ZipEntry("META-INF/container.xml"))
        zip.write("""<?xml version="1.0"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>""".toByteArray())
        zip.closeEntry()

        // 3. OPF
        val manifestItems = (1..chapterCount).joinToString("\n") { i ->
            """<item id="ch$i" href="chapter$i.xhtml" media-type="application/xhtml+xml"/>"""
        }
        val spineItems = (1..chapterCount).joinToString("\n") { i ->
            """<itemref idref="ch$i"/>"""
        }
        zip.putNextEntry(ZipEntry("OEBPS/content.opf"))
        zip.write("""<?xml version="1.0" encoding="utf-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="2.0">
  <metadata/>
  <manifest>$manifestItems</manifest>
  <spine>$spineItems</spine>
</package>""".toByteArray())
        zip.closeEntry()

        // 4. Chapters
        repeat(chapterCount) { i ->
            zip.putNextEntry(ZipEntry("OEBPS/chapter${i + 1}.xhtml"))
            zip.write(chapterContent.toByteArray())
            zip.closeEntry()
        }

        zip.close()
        return out.toByteArray()
    }

    private fun makeParser(epubBytes: ByteArray): EpubParser {
        val context = mock<Context>()
        val resolver = mock<ContentResolver>()
        val uri = mock<Uri>()
        whenever(context.contentResolver).thenReturn(resolver)
        whenever(resolver.openInputStream(any())).thenReturn(ByteArrayInputStream(epubBytes))
        return EpubParser(context)
    }

    // ── Tests ─────────────────────────────────────────────────────────────────

    @Test
    fun `parse returns correct chapter count`() {
        val epub = buildMinimalEpub(chapterCount = 3)
        val parser = makeParser(epub)
        val book = parser.parse(mock())
        assertEquals(3, book.chapters.size)
    }

    @Test
    fun `chapters are ordered by spine`() {
        val epub = buildMinimalEpub(chapterCount = 2)
        val parser = makeParser(epub)
        val book = parser.parse(mock())
        assertTrue(book.chapters[0].href.contains("chapter1"))
        assertTrue(book.chapters[1].href.contains("chapter2"))
    }

    @Test
    fun `parse preserves chapter HTML content`() {
        val content = "<html xmlns=\"http://www.w3.org/1999/xhtml\"><body><p>سلام دنیا</p></body></html>"
        val epub = buildMinimalEpub(chapterCount = 1, chapterContent = content)
        val parser = makeParser(epub)
        val book = parser.parse(mock())
        assertTrue(book.chapters.first().originalHtml.contains("سلام دنیا"))
    }

    @Test
    fun `parse stores container xml verbatim`() {
        val epub = buildMinimalEpub()
        val parser = makeParser(epub)
        val book = parser.parse(mock())
        assertTrue(book.containerXml.contains("content.opf"))
    }

    @Test
    fun `parse stores opf path correctly`() {
        val epub = buildMinimalEpub()
        val parser = makeParser(epub)
        val book = parser.parse(mock())
        assertEquals("OEBPS/content.opf", book.opfPath)
    }

    @Test(expected = IllegalArgumentException::class)
    fun `parse throws on missing container xml`() {
        // Build a ZIP with no META-INF/container.xml
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            zip.putNextEntry(ZipEntry("junk.txt"))
            zip.write("nothing".toByteArray())
            zip.closeEntry()
        }
        val parser = makeParser(out.toByteArray())
        parser.parse(mock())
    }
}
