package ir.persian.voiceoptimizer.rules

import ir.persian.voiceoptimizer.rules.diacritics.SmartDiacriticsRule
import org.junit.Assert.assertTrue
import org.junit.Test

class DiacriticsRulesTest {

    private val rule = SmartDiacriticsRule()

    @Test
    fun `SmartDiacriticsRule diacritizes است`() {
        val input = "این خوب است"
        val result = rule.process(input)
        assertTrue(result.contains("اَست"))
    }

    @Test
    fun `SmartDiacriticsRule diacritizes را`() {
        val input = "کتاب را خواند"
        val result = rule.process(input)
        assertTrue(result.contains("رَا"))
    }

    @Test
    fun `SmartDiacriticsRule diacritizes در`() {
        val input = "در خانه بود"
        val result = rule.process(input)
        assertTrue(result.contains("دَر"))
    }

    @Test
    fun `SmartDiacriticsRule is idempotent`() {
        val input = "این خوب است"
        val once = rule.process(input)
        val twice = rule.process(once)
        // Idempotent because word boundary prevents double-match on already-diacritized form
        assertTrue(twice.contains("اَست"))
    }
}
