# Jsoup
-keep public class org.jsoup.** { *; }

# Hilt
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }

# Kotlin coroutines
-keepnames class kotlinx.coroutines.** { *; }

# App domain models (used in Flow emissions)
-keep class ir.persian.voiceoptimizer.core.domain.model.** { *; }

# Keep all rules (dynamically iterated)
-keep class ir.persian.voiceoptimizer.rules.** { *; }
