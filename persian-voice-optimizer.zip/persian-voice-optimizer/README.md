# بهینه‌ساز صوتی فارسی
### Persian Voice Optimizer

یک اپلیکیشن Android آفلاین برای بهینه‌سازی فایل‌های EPUB فارسی جهت خواندن طبیعی توسط موتورهای TTS مانند SherpaTTS و Piper.

---

## ویژگی‌ها

| ویژگی | توضیح |
|-------|-------|
| تبدیل کاراکترهای عربی | `ك → ک`، `ي → ی`، `ى → ی` |
| نرمال‌سازی اعداد | `۱۲۳ → 123` |
| اصلاح فاصله‌گذاری | حذف فاصله قبل از `،` و `؟` |
| افزودن نیم‌فاصله | `میرود → می‌رود` |
| نرمال‌سازی اضافه | `خانهِ → خانه‌ی` |
| جایگزینی لینک‌ها | `https://... → (لینک)` |
| بسط مخفف‌های انگلیسی | `AI → هوش مصنوعی` |
| مکث‌های طبیعی (Human Voice) | نقطه‌گذاری مکث برای TTS انسانی |
| اعراب‌گذاری هوشمند | افزودن حرکات به کلمات پرکاربرد |
| حفظ ساختار EPUB | metadata، CSS، تصاویر، TOC دست‌نخورده می‌مانند |

---

## حالت‌های بهینه‌سازی

```
NORMAL       → تایپوگرافی + کاراکترهای پایه
NATURAL      → NORMAL + دستور زبان + TTS
HUMAN_VOICE  → NATURAL + مکث‌های انسانی + دیالوگ
```

---

## ساختار پروژه

```
app/src/main/java/ir/persian/voiceoptimizer/
├── core/
│   ├── di/          ← Hilt DI modules
│   └── domain/
│       ├── model/   ← EpubFile, OptimizationMode, ProcessingResult
│       └── usecase/ ← ProcessEpubUseCase (Flow-based)
├── epub/
│   ├── parser/      ← EpubParser (ZIP → OPF → chapters)
│   └── writer/      ← EpubWriter (chapters → ZIP)
├── processor/       ← TextProcessor (XHTML text-node walker)
├── rules/
│   ├── typography/  ← 4 rules
│   ├── grammar/     ← 4 rules
│   ├── tts/         ← 4 rules
│   ├── humanize/    ← 4 rules
│   └── diacritics/  ← 1 rule
└── ui/
    ├── screens/
    │   ├── home/    ← HomeScreen + HomeViewModel
    │   ├── preview/ ← PreviewScreen (before/after diff)
    │   └── settings/← SettingsScreen
    └── theme/       ← Material3 dark theme + Persian typography
```

---

## راه‌اندازی

### پیش‌نیازها
- Android Studio Jellyfish یا جدیدتر
- JDK 17
- Android SDK 35
- حداقل API 26 روی دستگاه/شبیه‌ساز

### مراحل

```bash
git clone https://github.com/your-org/persian-voice-optimizer.git
cd persian-voice-optimizer
gradle wrapper --gradle-version 8.7
./gradlew assembleDebug
```

فایل APK در `app/build/outputs/apk/debug/` قرار می‌گیرد.

---

## تست‌ها

```bash
./gradlew testDebugUnitTest
```

تست‌ها شامل:
- `TypographyRulesTest` — 9 تست
- `GrammarRulesTest` — 7 تست
- `TtsRulesTest` — 7 تست
- `DiacriticsRulesTest` — 4 تست
- `HumanizeRulesTest` — 7 تست
- `TextProcessorTest` — 8 تست (integration)
- `EpubParserTest` — 6 تست

---

## CI/CD

GitHub Actions (`.github/workflows/ci.yml`):

| مرحله | توضیح |
|-------|-------|
| `lint` | بررسی کیفیت کد |
| `testDebugUnitTest` | اجرای تمام unit test‌ها |
| `assembleDebug` | ساخت APK دیباگ |
| `assembleRelease` | فقط روی tag‌های `v*` |

---

## معماری

```
UI (Compose) → ViewModel → UseCase → Parser/Writer/Processor → Rules
```

- **Clean Architecture** — وابستگی یک‌طرفه از UI به domain
- **Hilt** — تزریق وابستگی
- **Coroutines + Flow** — پردازش async با progress واقعی
- **Offline-only** — بدون اینترنت، بدون تبلیغ، بدون ردیابی
- **RTL** — پشتیبانی کامل از راست‌به‌چپ

---

## Roadmap

| نسخه | هدف |
|------|-----|
| v0.1 | EPUB import/export ✅ |
| v0.2 | Rule engine ✅ |
| v0.3 | Preview screen ✅ |
| v0.4 | Smart diacritics ✅ |
| v0.5 | Human Voice mode ✅ |
| v1.0 | Stable release |

---

## مشارکت

- PR‌های کوچک و متمرکز
- unit test برای هر rule جدید الزامی است
- کد تکراری مجاز نیست
- API‌های public باید مستند شوند

---

## لایسنس

MIT License — آزاد برای استفاده شخصی و تجاری.
